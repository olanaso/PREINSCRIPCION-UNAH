<?php

/* Configuración privada de este servidor. Este archivo está excluido de Git. */
return array(
    'mail' => array(
        'transport' => 'smtp',
        'from_address' => 'noreply@unah.sisadmision.com',
        'from_name' => 'Admisiones UNAH',
        'reply_to' => 'noreply@unah.sisadmision.com',
        'host' => 'unah.sisadmision.com',
        'port' => 465,
        'encryption' => 'ssl',
        'username' => 'noreply@unah.sisadmision.com',
        'password' => '2#(H1k~OD0WAonn]',
        'timeout' => 20,
        'verify_peer' => true,
    ),
);
